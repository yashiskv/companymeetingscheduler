package com.example.companymeetingscheduler;

public interface Api {
    public ScheduleApi getScheduleApi();
}
