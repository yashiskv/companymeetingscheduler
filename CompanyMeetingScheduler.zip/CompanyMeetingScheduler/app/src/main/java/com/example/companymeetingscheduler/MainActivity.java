package com.example.companymeetingscheduler;

import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.LifecycleOwner;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;
import androidx.lifecycle.ViewModelProviders;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.util.Log;

import java.net.URL;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {
    ScheduleViewModel scheduleViewModel;
    ScheduleCustomAdapter scheduleCustomAdapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        scheduleCustomAdapter = new ScheduleCustomAdapter(getApplicationContext());
        RecyclerView recyclerView = findViewById(R.id.schedule_list);
        recyclerView.setLayoutManager(new LinearLayoutManager(getApplicationContext()));
        recyclerView.setAdapter(scheduleCustomAdapter);

        DateFormat df = new SimpleDateFormat("dd/MM/yy HH:mm:ss");
        Calendar cal = Calendar.getInstance();
        String dateTime = df.format(cal.getTime());
        String[] arr = dateTime.split("\\s+");
        String date = arr[0];
        Log.d("Yashi",date);
        ScheduleApi scheduleApi = new RetrofitApi("http://fathomless-shelf-5846.herokuapp.com").getScheduleApi();
        ScheduleViewModelFactory factory = new ScheduleViewModelFactory(new ScheduleRepository(scheduleApi));
        scheduleViewModel = new ViewModelProvider(MainActivity.this, factory).get(ScheduleViewModel.class);

        scheduleViewModel.getDailyScheduleLog(date).observe(this, scheduleLogs -> {
            Log.d("Yashi Inside Activity",scheduleLogs.toString());
            scheduleCustomAdapter.setScheduleLogs(scheduleLogs);
        });
    }
}